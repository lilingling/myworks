var show_list = {
  "1":{
    "name":"开心麻花经典爆笑舞台剧<br/>《乌龙山伯爵》第三十八轮",
    "pic":"1",
    "time":"2016.1.1-1.3",
    "desc":"开心麻花戏剧结构最精致的舞台剧，巡演数十轮，热度依旧不减。",
    "price":"180元起",
    "link":"wxmovie://showdetail?onlineid=b6122012c6604789b5fe9fedb95bab22"
  },
  "2":{
    "name":"开心麻花爆笑音乐喜剧<br/>《爷们儿-叁》第十八轮",
    "pic":"2",
    "time":"2016.1.7-1.17",
    "desc":"相亲还能去寻宝？不小心我上了贼船！",
    "price":"180元起",
    "link":"wxmovie://showdetail?onlineid=464532f6299848a9acc965bf29a8aff8"
  },
  "3":{
    "name":"星际迷航50周年特展系列讲座<br/>星际航行 触碰未来",
    "pic":"3",
    "time":"2015.12.10-2016.2.22",
    "desc":"进取号开到家门口，请用瓦肯手礼打船 LLAP!",
    "price":"100元起",
    "link":"wxmovie://showdetail?onlineid=01ed2fc7dec64b478f9f72e88f137f7c"
  },
  "4":{
    "name":"贺岁喜剧<br/>《芳心之罪》",
    "pic":"4",
    "time":"2015.12.22-2016.1.3",
    "desc":"奥斯卡提名、普利策奖、托尼奖",
    "price":"50元起",
    "link":"wxmovie://showdetail?onlineid=337284800e2d45eeb52f1badcec290bf"
  },
  "5":{
    "name":"乐在其中巡回演唱会<br/>孙楠北京站",
    "pic":"5",
    "time":"2015.12.24",
    "desc":"圣诞狂欢夜，和孙楠一起过",
    "price":"380元起",
    "link":"wxmovie://showdetail?onlineid=3f4ee8f7807f4e72ad97b802b35111d1"
  },
  "6":{
    "name":'“日落黑趴”世界巡回演唱会<br/>兄弟本色深圳站',
    "pic":"6",
    "time":"2016.1.16",
    "desc":"「兄弟本色」 = 张震岳 x MCHotDog热狗 x MJ116顽童",
    "price":"180元起",
    "link":"wxmovie://showdetail?onlineid=7669808f09cf41389fc43c45eaffafb8"
  }

}
